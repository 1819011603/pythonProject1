import numpy as np
from sklearn.model_selection import train_test_split

from utils import *


def get_iter(x0):
    global bb

    for i in range(len(bb)):
        f = list(bb[0:i])
        f.extend(bb[i + 1:])  # index
        ans = list(splits[f[0]])
        for v in f[1:]:
            ans.extend(splits[v])  # splits
        xx = []
        for m in x0:
            xx.append(m[ans])
        yield np.array(xx)  # x0


def getNext(j):
    global splits, bb
    bb.remove(j)
    if len(bb) == 0:
        return None
    ans = list(splits[bb[0]])
    for f in bb[1:]:
        ans.extend(splits[f])
    return ans


def getSplitsAndIndices(split_len=10):
    l = np.shape(x0)[1]
    len1 = int(np.floor(l / split_len))  # 剩余的尾巴不要了
    a = list(np.arange(l))
    b = list(np.arange(len1))
    splits = []
    u = 0
    for i in range(len1):
        splits.append(a[u:u + split_len])
        u += split_len
    # splits.append(a[u:])
    return splits, b
def main(s_len = 11):

    global x0,bb,splits

    x0, y0 = loadDataSet01('./PLS-master/data/test_all_reflect1.txt', ', ')  # 单因变量与多因变量
    x0 = filter(x0)


    splits, bb = getSplitsAndIndices(split_len=s_len)

    # print(getNext(1))
    # print(getNext(2))
    # print(getNext(3))
    # print(getNext(23))
    m = 0
    m_j = 0
    b_ = []

    rm = 10
    rm_j = 1
    mylog = open(get_log_name(), mode='a', encoding='utf-8')

    while len(bb) > ceil(11.0 / s_len):
        k = 0
        p = get_iter(x0)
        max = 0
        max_j = 0
        for x in p:
            x_train, x_test, y_train, y_test = train_test_split(
                x, y0, test_size=0.2, random_state=3)

            RR, RMSE = PLS(x_train, x_test, y_train, y_test)
            # print("{} RR: {} RMSE: {}".format(k, RR, RMSE), file=mylog)
            if max < RR:
                max = RR
                max_j = k
            if rm > RMSE:
                rm = RMSE
                rm_j = len(bb)
            k += 1

        if m < max or abs(max-m) < 0.001:

            m_j = len(bb)
            b_ = list(bb)
            if m < max:
                m = max
        print("max_RR: {}, delete group is {}".format(max,bb[max_j]), file=mylog)
        bb.remove(bb[max_j])
        print(bb, file=mylog)

    print(file=mylog)
    print('the best groups: {}'.format(b_), file=mylog)
    print("R2_max:{}, b_len: {}".format(m, m_j), file=mylog)
    print("rmse_min: {}, b_len: {}".format(rm,rm_j),file=mylog)
    # print(bb,file=mylog)
    mylog.close()
    # print(x)
    # print(np.shape(x))
    # break
    # print(len)
    # print(x0)
if __name__ == '__main__':
    import time
    start = time.clock()
    main(s_len=1)
    end = time.clock()
    print("the spent time is {}s".format((end - start) / 1000))